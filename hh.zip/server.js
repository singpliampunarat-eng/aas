/**
 * Tellonym Inbox Dashboard — server.js v2
 * 
 * New env vars needed (add to Replit Secrets):
 *   GEMINI_API_KEY        — Google AI Studio key
 *   IG_USER_ID            — Instagram Business account user ID
 *   IG_ACCESS_TOKEN       — Long-lived Instagram Graph API token
 *   SUPABASE_URL          — Supabase project URL
 *   SUPABASE_KEY          — Supabase service_role key
 *   TELLONYM_TOKEN        — Tellonym Bearer token
 *   DASHBOARD_PASSWORD    — (optional) dashboard password
 */

const express   = require('express');
const cors      = require('cors');
const path      = require('path');
const fs        = require('fs');
const { createCanvas } = require('canvas');
const { createClient } = require('@supabase/supabase-js');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Clients ──
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const genAI    = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Auth middleware ──
const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD;
function auth(req, res, next) {
  if (!DASHBOARD_PASSWORD) return next();
  const p = req.headers['x-dashboard-password'] || req.query.pwd;
  if (p !== DASHBOARD_PASSWORD) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

// ════════════════════════════════════════════════
//  1. SCREENSHOT — generate a styled PNG card
// ════════════════════════════════════════════════
const CARD_W = 1080;
const CARD_H = 1080;

function wrapText(ctx, text, maxWidth) {
  const words = text.split(' ');
  const lines = [];
  let line = '';
  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function generateCard(content, category = 'other', categoryLabel = '') {
  const canvas = createCanvas(CARD_W, CARD_H);
  const ctx    = canvas.getContext('2d');

  // Background gradient
  const bg = ctx.createLinearGradient(0, 0, CARD_W, CARD_H);
  bg.addColorStop(0, '#0d0d14');
  bg.addColorStop(1, '#1a1a2e');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, CARD_W, CARD_H);

  // Subtle grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.03)';
  ctx.lineWidth = 1;
  for (let x = 0; x < CARD_W; x += 60) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, CARD_H); ctx.stroke();
  }
  for (let y = 0; y < CARD_H; y += 60) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(CARD_W, y); ctx.stroke();
  }

  // Amber glow orb
  const glow = ctx.createRadialGradient(CARD_W/2, CARD_H/2, 0, CARD_W/2, CARD_H/2, 420);
  glow.addColorStop(0, 'rgba(245,166,35,0.07)');
  glow.addColorStop(1, 'rgba(245,166,35,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, CARD_W, CARD_H);

  // Top bar
  ctx.fillStyle = 'rgba(245,166,35,0.12)';
  ctx.fillRect(0, 0, CARD_W, 80);
  ctx.fillStyle = '#f5a623';
  ctx.fillRect(0, 0, 4, 80);

  // "tellonym" label
  ctx.fillStyle = '#f5a623';
  ctx.font = 'bold 22px monospace';
  ctx.fillText('TELLONYM', 28, 50);

  // Category badge
  const categoryColors = {
    funny:      '#f5a623',
    compliment: '#2ed573',
    question:   '#5352ed',
    advice:     '#1e90ff',
    negative:   '#ff4757',
    sensitive:  '#ff6b81',
    other:      '#747d8c',
  };
  const badgeColor = categoryColors[category] || '#747d8c';
  const badgeText  = (categoryLabel || category).toUpperCase();
  const badgeW     = ctx.measureText(badgeText).width + 28;
  const badgeX     = CARD_W - badgeW - 28;

  ctx.fillStyle = badgeColor + '33';
  ctx.strokeStyle = badgeColor;
  ctx.lineWidth = 1.5;
  const br = 4;
  ctx.beginPath();
  ctx.roundRect(badgeX, 22, badgeW, 34, br);
  ctx.fill(); ctx.stroke();
  ctx.fillStyle = badgeColor;
  ctx.font = 'bold 16px monospace';
  ctx.fillText(badgeText, badgeX + 14, 44);

  // Opening quote mark
  ctx.fillStyle = 'rgba(245,166,35,0.15)';
  ctx.font = 'bold 220px serif';
  ctx.fillText('\u201C', 48, 420);

  // Message text
  ctx.fillStyle = '#ffffff';
  ctx.font = '46px Georgia, serif';
  const maxW = CARD_W - 120;
  const lines = wrapText(ctx, content, maxW);

  // Calculate vertical centering
  const lineH   = 68;
  const totalH  = lines.length * lineH;
  let   startY  = (CARD_H - totalH) / 2 + 24;
  if (startY < 160) startY = 160;

  lines.forEach((line, i) => {
    ctx.fillText(line, 60, startY + i * lineH);
  });

  // Bottom bar
  ctx.fillStyle = 'rgba(255,255,255,0.04)';
  ctx.fillRect(0, CARD_H - 80, CARD_W, 80);
  ctx.fillStyle = 'rgba(255,255,255,0.2)';
  ctx.font = '20px monospace';
  ctx.fillText('answer this on my tellonym ✦', 60, CARD_H - 26);

  return canvas.toBuffer('image/png');
}

// ════════════════════════════════════════════════
//  2. GEMINI — categorize message
// ════════════════════════════════════════════════
const CATEGORIES = {
  funny:      { label: 'Funny / Meme',   color: '#f5a623' },
  compliment: { label: 'Compliment',     color: '#2ed573' },
  question:   { label: 'Question',       color: '#5352ed' },
  advice:     { label: 'Advice / Help',  color: '#1e90ff' },
  negative:   { label: 'Negative',       color: '#ff4757' },
  sensitive:  { label: 'Sensitive',      color: '#ff6b81' },
  other:      { label: 'Other',          color: '#747d8c' },
};

async function categorizeMessage(content) {
  try {
    const model  = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    const prompt = `Categorize this anonymous Tellonym message into exactly one category.

Message: "${content}"

Categories:
- funny       → jokes, memes, playful messages
- compliment  → kind words, praise, admiration
- question    → genuine questions about the person
- advice      → asking for help, opinions, recommendations
- negative    → rude, mean, hurtful, or offensive messages
- sensitive   → personal, emotional, or potentially distressing topics
- other       → everything else

Reply with ONLY a JSON object, no markdown, no explanation:
{"category":"<one of the 7 keys above>","reason":"<one short sentence>"}`;

    const result = await model.generateContent(prompt);
    const text   = result.response.text().trim().replace(/```json|```/g, '');
    const parsed = JSON.parse(text);
    const cat    = CATEGORIES[parsed.category] ? parsed.category : 'other';
    return {
      category:       cat,
      category_label: CATEGORIES[cat].label,
      category_color: CATEGORIES[cat].color,
      reason:         parsed.reason || '',
    };
  } catch (e) {
    console.error('[gemini] categorization error:', e.message);
    return { category: 'other', category_label: 'Other', category_color: '#747d8c' };
  }
}

// ════════════════════════════════════════════════
//  3. INSTAGRAM — post image via Graph API
// ════════════════════════════════════════════════
const IG_API = 'https://graph.facebook.com/v19.0';

async function postToInstagram(imageUrl) {
  const userId = process.env.IG_USER_ID;
  const token  = process.env.IG_ACCESS_TOKEN;
  if (!userId || !token) throw new Error('IG_USER_ID or IG_ACCESS_TOKEN not set');

  // Step 1: Create media container
  const createRes = await fetch(
    `${IG_API}/${userId}/media?image_url=${encodeURIComponent(imageUrl)}&caption=&access_token=${token}`,
    { method: 'POST' }
  );
  const createData = await createRes.json();
  if (createData.error) throw new Error(`IG create container: ${createData.error.message}`);

  const containerId = createData.id;
  if (!containerId) throw new Error('No container ID returned from Instagram');

  // Step 2: Wait a moment for processing
  await new Promise(r => setTimeout(r, 3000));

  // Step 3: Publish
  const publishRes = await fetch(
    `${IG_API}/${userId}/media_publish?creation_id=${containerId}&access_token=${token}`,
    { method: 'POST' }
  );
  const publishData = await publishRes.json();
  if (publishData.error) throw new Error(`IG publish: ${publishData.error.message}`);

  return publishData.id;
}

// ════════════════════════════════════════════════
//  4. SYNC — fetch from Tellonym, process each
// ════════════════════════════════════════════════
const TELLONYM_API = 'https://api.tellonym.me';

async function fetchTellonymMessages(limit = 50, offset = 0) {
  const res = await fetch(`${TELLONYM_API}/tells/received?limit=${limit}&offset=${offset}`, {
    headers: {
      'Authorization': `Bearer ${process.env.TELLONYM_TOKEN}`,
      'User-Agent': 'TellonymApp/3 CFNetwork/1494.0.7 Darwin/23.4.0',
      'tellonym-client': 'ios:3.44.0',
      'Accept': 'application/json',
    }
  });
  if (!res.ok) throw new Error(`Tellonym API ${res.status}`);
  return res.json();
}

async function processMessage(msg) {
  // 1. Categorize with Gemini
  const cat = await categorizeMessage(msg.content);

  // 2. Generate PNG card
  const pngBuffer = generateCard(msg.content, cat.category, cat.category_label);

  // 3. Upload to Supabase Storage
  const fileName = `${msg.external_id}.png`;
  const { error: uploadErr } = await supabase.storage
    .from('message-cards')
    .upload(fileName, pngBuffer, { contentType: 'image/png', upsert: true });

  if (uploadErr) throw new Error('Storage upload: ' + uploadErr.message);

  const { data: { publicUrl } } = supabase.storage
    .from('message-cards')
    .getPublicUrl(fileName);

  return { ...cat, screenshot_url: publicUrl };
}

async function syncMessages() {
  console.log(`[${new Date().toISOString()}] Syncing…`);
  let totalNew = 0;
  let offset   = 0;

  while (true) {
    const data  = await fetchTellonymMessages(50, offset);
    const tells = data.tells || data.data || [];
    if (!tells.length) break;

    for (const t of tells) {
      const extId = String(t.id);

      // Check if already stored
      const { data: existing } = await supabase
        .from('messages').select('id').eq('external_id', extId).maybeSingle();
      if (existing) continue;

      const content    = t.tell || t.text || t.content || '';
      const receivedAt = t.createdAt || t.created_at || new Date().toISOString();

      try {
        const processed = await processMessage({ external_id: extId, content });

        await supabase.from('messages').insert({
          external_id:     extId,
          source:          'tellonym',
          content,
          likes:           t.likes_count || 0,
          is_read:         false,
          status:          'pending',
          category:        processed.category,
          category_label:  processed.category_label,
          category_color:  processed.category_color,
          screenshot_url:  processed.screenshot_url,
          received_at:     receivedAt,
          raw:             t,
        });

        totalNew++;
        console.log(`  [+] ${extId} → ${processed.category}`);
      } catch (e) {
        console.error(`  [!] Failed to process ${extId}:`, e.message);
      }

      await new Promise(r => setTimeout(r, 300));
    }

    if (tells.length < 50) break;
    offset += 50;
  }

  console.log(`[sync] Done — ${totalNew} new`);
  return totalNew;
}

// ════════════════════════════════════════════════
//  5. API ROUTES
// ════════════════════════════════════════════════

// GET messages
app.get('/api/messages', auth, async (req, res) => {
  const { status, limit = 200 } = req.query;
  let q = supabase
    .from('messages')
    .select('id,external_id,content,likes,is_read,status,category,category_label,category_color,screenshot_url,ig_post_id,ig_posted_at,received_at')
    .order('received_at', { ascending: false })
    .limit(Number(limit));
  if (status) q = q.eq('status', status);
  const { data, error } = await q;
  if (error) return res.status(500).json({ error: error.message });
  res.json({ messages: data });
});

// POST manual sync
app.post('/api/sync', auth, async (req, res) => {
  try {
    const new_count = await syncMessages();
    res.json({ ok: true, new_count });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// PATCH mark read
app.patch('/api/messages/:id/read', auth, async (req, res) => {
  const { error } = await supabase.from('messages').update({ is_read: true }).eq('id', req.params.id);
  if (error) return res.status(500).json({ error: error.message });
  res.json({ ok: true });
});

// POST accept — post to Instagram
app.post('/api/messages/:id/accept', auth, async (req, res) => {
  const { id } = req.params;

  // Get message
  const { data: msg, error: fetchErr } = await supabase
    .from('messages').select('*').eq('id', id).single();
  if (fetchErr || !msg) return res.status(404).json({ error: 'Message not found' });
  if (!msg.screenshot_url) return res.status(400).json({ error: 'No screenshot URL — run sync first' });

  try {
    const igPostId = await postToInstagram(msg.screenshot_url);
    await supabase.from('messages').update({
      status:       'accepted',
      is_read:      true,
      ig_post_id:   igPostId,
      ig_posted_at: new Date().toISOString(),
    }).eq('id', id);
    res.json({ ok: true, ig_post_id: igPostId });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST reject
app.post('/api/messages/:id/reject', auth, async (req, res) => {
  const { error } = await supabase.from('messages').update({
    status:  'rejected',
    is_read: true,
  }).eq('id', req.params.id);
  if (error) return res.status(500).json({ error: error.message });
  res.json({ ok: true });
});

// GET health
app.get('/api/health', (req, res) => {
  res.json({
    supabase:  process.env.SUPABASE_URL    ? '✓' : '✗',
    tellonym:  process.env.TELLONYM_TOKEN  ? '✓' : '✗',
    gemini:    process.env.GEMINI_API_KEY  ? '✓' : '✗',
    instagram: process.env.IG_ACCESS_TOKEN ? '✓' : '✗',
  });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Auto-sync ──
const SYNC_INTERVAL = Number(process.env.SYNC_INTERVAL_MS) || 120_000;
syncMessages().catch(console.error);
setInterval(() => syncMessages().catch(console.error), SYNC_INTERVAL);

app.listen(PORT, () => console.log(`Dashboard on port ${PORT}`));
