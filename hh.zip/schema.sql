-- ══════════════════════════════════════════════
--  Tellonym Inbox Dashboard — Supabase Schema v2
--  Run this in: Supabase Dashboard → SQL Editor
-- ══════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS messages (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id     TEXT        NOT NULL UNIQUE,
  source          TEXT        NOT NULL DEFAULT 'tellonym',
  content         TEXT        NOT NULL,
  likes           INTEGER     NOT NULL DEFAULT 0,
  is_read         BOOLEAN     NOT NULL DEFAULT FALSE,

  -- Moderation
  status          TEXT        NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','accepted','rejected')),

  -- Gemini categorization
  category        TEXT,        -- funny | compliment | question | advice | negative | sensitive | other
  category_label  TEXT,
  category_color  TEXT,        -- hex for badge

  -- Screenshot card URL (Supabase Storage)
  screenshot_url  TEXT,

  -- Instagram post result
  ig_post_id      TEXT,
  ig_posted_at    TIMESTAMPTZ,

  received_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  raw             JSONB
);

CREATE INDEX IF NOT EXISTS messages_received_at_idx ON messages (received_at DESC);
CREATE INDEX IF NOT EXISTS messages_status_idx      ON messages (status);
CREATE INDEX IF NOT EXISTS messages_is_read_idx     ON messages (is_read);
CREATE INDEX IF NOT EXISTS messages_external_id_idx ON messages (external_id);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service role only" ON messages FOR ALL USING (FALSE);

-- ── Storage bucket for card screenshots ──
INSERT INTO storage.buckets (id, name, public)
VALUES ('message-cards', 'message-cards', TRUE)
ON CONFLICT DO NOTHING;

CREATE POLICY "Service role upload"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'message-cards');

CREATE POLICY "Public read"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'message-cards');

-- ── Stats view ──
CREATE OR REPLACE VIEW message_stats AS
SELECT
  COUNT(*)                                                          AS total,
  COUNT(*) FILTER (WHERE NOT is_read)                               AS unread,
  COUNT(*) FILTER (WHERE status = 'pending')                        AS pending,
  COUNT(*) FILTER (WHERE status = 'accepted')                       AS accepted,
  COUNT(*) FILTER (WHERE status = 'rejected')                       AS rejected,
  COUNT(*) FILTER (WHERE received_at > NOW() - INTERVAL '24 hours') AS last_24h;
