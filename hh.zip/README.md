# 📬 Tellonym Inbox Dashboard v2

Screenshot every Tellonym message → Gemini categorizes it → you Accept or Reject → accepted ones auto-post to Instagram.

---

## How it works

```
Tellonym API
    ↓ (every 2 min)
Generate PNG card (node-canvas)
    ↓
Gemini Flash → categorize (funny / compliment / question / advice / negative / sensitive / other)
    ↓
Store in Supabase (message + card image)
    ↓
Dashboard → you review each card
    ↓
Accept → Instagram Graph API posts the PNG with no caption
Reject → marked rejected, never posted
```

---

## Step 1 — Supabase

1. Create a project at [supabase.com](https://supabase.com)
2. **SQL Editor** → paste `schema.sql` → Run
3. **Settings → API** → copy:
   - `Project URL` → `SUPABASE_URL`
   - `service_role` secret → `SUPABASE_KEY`
4. Go to **Storage** → confirm the `message-cards` bucket was created (it's created by the SQL, but double-check it's set to **public**)

---

## Step 2 — Tellonym Token

1. Open [tellonym.me](https://tellonym.me) in Chrome, log in
2. Press **F12** → **Network** tab → reload the page
3. Click any request to `api.tellonym.me`
4. In **Request Headers**, find: `Authorization: Bearer XXXXXXXX`
5. Copy the token part → `TELLONYM_TOKEN`

> Tokens expire after a few weeks. If sync stops, repeat this step.

---

## Step 3 — Gemini API Key

1. Go to [aistudio.google.com](https://aistudio.google.com)
2. Click **Get API key** → Create API key
3. Copy it → `GEMINI_API_KEY`

---

## Step 4 — Instagram Graph API

Your Instagram account must be a **Business** or **Creator** account linked to a Facebook Page.

### Get your credentials:

1. Go to [developers.facebook.com](https://developers.facebook.com) → Create App → choose **Business**
2. Add the **Instagram Graph API** product
3. Under **Instagram → Basic Display** or **Instagram Graph API**:
   - Get your **Instagram User ID** → `IG_USER_ID`
4. Generate a **long-lived User Access Token** with these permissions:
   - `instagram_basic`
   - `instagram_content_publish`
   - `pages_read_engagement`
5. Copy the token → `IG_ACCESS_TOKEN`

> Long-lived tokens last ~60 days. You'll need to refresh periodically.  
> Use the [Token Debugger](https://developers.facebook.com/tools/debug/accesstoken/) to check expiry.

---

## Step 5 — Replit Setup

1. Create a **Node.js** Repl at [replit.com](https://replit.com)
2. Upload files in this structure:
   ```
   replit-project/
   ├── server.js
   ├── package.json
   └── public/
       └── index.html     ← must be inside /public/
   ```
3. Click the **Secrets** tab (🔒) and add:

| Secret Key | Value |
|---|---|
| `SUPABASE_URL` | Your Supabase project URL |
| `SUPABASE_KEY` | Your Supabase **service_role** key |
| `TELLONYM_TOKEN` | Your Tellonym Bearer token |
| `GEMINI_API_KEY` | Your Google AI Studio API key |
| `IG_USER_ID` | Your Instagram business user ID |
| `IG_ACCESS_TOKEN` | Your Instagram long-lived access token |
| `DASHBOARD_PASSWORD` | A password for the dashboard (optional) |
| `SYNC_INTERVAL_MS` | `120000` (2 min) — or lower |

4. Open the **Shell** tab and run:
   ```bash
   npm install
   ```
5. Hit **Run** — your dashboard goes live at your Replit URL

---

## Dashboard Features

- **Auto-syncs** every 2 minutes — new Tellonym messages appear automatically
- Each message gets a **styled PNG card** generated server-side
- **Gemini** categorizes each one: Funny, Compliment, Question, Advice, Negative, Sensitive, Other
- **Filter** by status (Pending / Accepted / Rejected) or category
- Click any message → **Accept & Post** or **Reject**
- Accepted → card image posts to your Instagram instantly (no caption)
- Rejected → stays in dashboard, never posted

---

## Keep Replit Awake

Free Replit projects sleep after inactivity. Fix this with:
- [UptimeRobot](https://uptimerobot.com) — free, ping your URL every 5 min
- Or upgrade to a Replit paid plan

---

## Troubleshooting

| Problem | Fix |
|---|---|
| No messages syncing | Check `TELLONYM_TOKEN` — may have expired |
| Gemini returns "other" for everything | Check `GEMINI_API_KEY` is valid |
| Instagram post fails 400 | Token missing `instagram_content_publish` permission |
| Instagram post fails 190 | Token expired — generate a new long-lived token |
| "Storage upload" error | Check `message-cards` bucket exists and is public in Supabase |
| Supabase RLS error | Make sure you're using `service_role` key, not `anon` |

Visit `/api/health` on your Replit URL to see which env vars are set.
